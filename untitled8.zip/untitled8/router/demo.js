const express=require('express');
const pool=require('../pool.js');
var router=express.Router();
router.post("/denglu",(req,res)=>{
    var $uname=req.body.zhanghao;
    var $upwd=req.body.mima;
    if(!$uname){
        res.send("用户名不存在");
        return;
    }
    if(!$upwd){
        res.send("密码不存在");
        return;
    }
    var sql="select * from user where zhanghao=? and mima=?";
    pool.query(sql,[$uname,$upwd],(err,result)=>{;
        if(err) throw err;
        if(result.length>0){
            res.send(result);
        }else{
            res.send("sb");
        }
    });
});
router.post('/zhuche',(req,res)=>{
    var $zh=req.body;
    var $mm=req.body.mima;
    var $dh=req.body.phone;
    var $yx=req.body.youxiang;
    console.log($zh,"*",$mm,"*",$dh,"*",$yx);
    var sql="INSERT INTO user SET ?";
    pool.query(sql,[$zh],(err,result)=>{
        if(err) throw err;
        res.send("注册成功");
    });
});
router.post('/yzyh',(req,res)=>{
    var yh=req.body.zhanghao;
    var sql="select * from user where zhanghao=?";
    pool.query(sql,[yh],(err,result)=>{
        console.log(11111111);
        if(err) throw err;
        if(result.length>0) {
            res.send("cg");
        }
    });
})
router.get("/userlist",(req,res)=>{
    var $uid=req.query.uid
    console.log($uid);
    var sql="select * from user where uid=?";
    pool.query(sql,[$uid],(err,result)=>{
        if(err) throw err;
        res.send(result);

    });
});

router.get("/upxl",(req,res)=>{
    var $uid=req.query.uid
    console.log($uid);
    var sql="select * from zdian where uid=?";
    pool.query(sql,[$uid],(err,result)=>{
        if(err) throw err;
        console.log(result)
        res.send(result);

    });
});

router.post("/update",(req,res)=>{
    var $uid=req.body.uid;
    var $zhanghao=req.body.zhanghao;
    var $qom=req.body.qom;
    var $youxiang=req.body.youxiang;
    var $yw=req.body.yw;
    var $wz=req.body.wz;
    var $dz=req.body.dz;
    var $xs=req.body.xs;
    var $hy=req.body.hy;
    console.log($zhanghao)
    console.log($qom)
    console.log($yw)
    console.log($youxiang,$hy,$wz,$xs,)
    var sql="update user set zhanghao=?,qom=?,youxiang=?,yw=?,wz=?,dz=?,xiaos=?,hangye=? where uid=?";
    pool.query(sql,[$zhanghao,$qom,$youxiang,$yw,$wz,$dz,$xs,$hy,$uid],(err,result)=>{
        if(err) throw err;
        res.send("修改成功");
    });
});
router.get("/zy",(req,res)=>{
    var $uid=req.query.uid
    console.log($uid);
    var sql="select * from user where uid=?";
    pool.query(sql,[$uid],(err,result)=>{
        if(err) throw err;
        res.send(result);

    });
});
module.exports = router

