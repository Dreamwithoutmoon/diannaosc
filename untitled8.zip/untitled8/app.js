const express=require('express');
const bodyParser=require('body-parser');
const demo=require('./router/demo.js');
var server=express();
server.listen(8081);
server.use(express.static('public'));
server.use(express.static('node_modules'));
server.use(express.static('css'));
server.use(express.static('img'));
server.use(bodyParser.urlencoded({
    extended:false
}));
server.use('/demo',demo);

