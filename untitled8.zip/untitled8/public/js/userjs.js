
$("#page2").load("heard.html");
var btn=document.querySelectorAll(".htym2");
for(var btns of btn) {
    btns.onmouseover = function () {
        this.style.background = "#319bca";
    }
    btns.onmouseout = function () {
        this.style.background = ""

    }
}
